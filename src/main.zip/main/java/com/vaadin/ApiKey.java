/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java.com.vaadin;


public class ApiKey {
    private String key;

    public ApiKey() {
        this.key = "AIzaSyAIwb2B3taIvq955x0CxMnOzR0VRL4VtxU";
    }
    public String getKey(){
        return key;
     }
}

